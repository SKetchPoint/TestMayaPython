def String_Print_1():
    print("Fuck")